# Dayat Chat

Website chat pribadi bergaya WhatsApp: HTML/CSS/JavaScript + Supabase Auth, PostgreSQL, Row Level Security (RLS), dan Realtime. Bisa di-host gratis di Vercel.

## 1. Buat database Supabase
1. Buka https://supabase.com/ dan buat project baru.
2. Buka **SQL Editor → New query**.
3. Salin seluruh isi `supabase/schema.sql`, tempel, lalu tekan **Run**.
4. Buka **Project Settings → API** (di beberapa tampilan: **Connect**). Salin **Project URL** dan **anon/public key** atau **publishable key**. Jangan pernah gunakan `service_role` / secret key di browser.

## 2. Isi konfigurasi website
Buka `app.js`, ubah dua baris paling atas:
```js
const SUPABASE_URL = "PASTE_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE";
```
menjadi URL dan anon/publishable key dari project Supabase. Key publik memang dipakai browser; keamanan data ditegakkan oleh RLS. Jangan memasukkan password database atau service-role key ke file ini.

## 3. Daftarkan akun Dayat dan jadikan Owner
1. Deploy website dulu (langkah 4–5 di bawah), lalu buka websitenya.
2. Pilih **Daftar**, masukkan username `Dayat`, email milikmu, dan password kuat.
3. Jika konfirmasi email aktif, buka email konfirmasi lalu masuk ke website.
4. Di Supabase, buka **SQL Editor** dan jalankan:
```sql
select id, email, raw_user_meta_data->>'username' as username
from auth.users
order by created_at desc;
```
5. Cari baris akun milikmu dan salin nilai `id`-nya. Jalankan query berikut dengan UUID akunmu sendiri:
```sql
update public.profiles
set role = 'owner'
where id = 'GANTI_DENGAN_UUID_AKUN_DAYAT';
```
6. Keluar dari Dayat Chat lalu masuk kembali. Akunmu sekarang menampilkan role OWNER. Jangan bagikan akses dashboard Supabase kepada orang yang tidak dipercaya. Hanya lakukan klaim Owner melalui SQL Editor milik project sendiri.

**Penting:** jangan menjalankan query owner untuk akun orang lain. Website tidak mengizinkan pengguna biasa mengangkat diri menjadi Owner.

## 4. Upload project ke GitHub
1. Masuk ke https://github.com/ lalu buat repository baru bernama `dayat-chat`.
2. Tambahkan/upload file dan folder dari project ini. Pastikan `index.html`, `style.css`, `app.js`, `README.md`, dan folder `supabase/schema.sql` ada di root repository.
3. Commit perubahan. Repository boleh public karena konfigurasi browser hanya memakai URL dan anon/publishable key; tetap jangan pernah commit secret key.

Cara paling mudah dari HP: buka repository → **Add file → Upload files**, unggah file-file tersebut. Jika upload folder sulit, buat folder `supabase` melalui tampilan GitHub lalu unggah `schema.sql` ke dalamnya.

## 5. Deploy di Vercel
1. Buka https://vercel.com/ dan masuk menggunakan akun GitHub.
2. Tekan **Add New → Project**, pilih repository `dayat-chat`, lalu **Import**.
3. Framework preset: **Other**. Root directory: `./`. Build command dan output directory dapat dikosongkan untuk website statis ini.
4. Tekan **Deploy**. Setelah selesai, buka URL `.vercel.app` yang diberikan.

Karena konfigurasi Supabase disimpan di `app.js`, kamu tidak perlu memasukkan environment variable di Vercel untuk versi ini. Jika mengubah file di GitHub setelah import, Vercel biasanya membuat deployment baru otomatis.

## 6. Pengaturan Supabase Auth
Di Supabase, buka **Authentication → URL Configuration**:
- **Site URL**: isi URL Vercel kamu, contoh `https://dayat-chat.vercel.app`.
- Tambahkan URL tersebut ke **Redirect URLs** jika diperlukan.
- Untuk pengalaman yang lebih aman, biarkan konfirmasi email aktif. Teman harus mengonfirmasi email sebelum login jika fitur ini diwajibkan oleh project.

## 7. Cara menggunakan
1. Dayat daftar dan klaim role Owner lewat SQL seperti langkah 3.
2. Minta teman membuat akun dengan email dan username unik.
3. Setelah login, daftar akun tampil di panel **Teman**. Tekan nama teman untuk membuka chat.
4. Pesan tersimpan di database dan akan muncul real-time selama kedua akun terhubung ke internet.
5. Owner bisa mengubah role akun lain menjadi Admin atau Member melalui **Panel Owner**.

## Catatan dan batasan versi awal
- Fitur ini menyediakan chat teks pribadi; belum ada panggilan suara/video, pengiriman gambar/file, pesan terenkripsi end-to-end, atau notifikasi push.
- Password ditangani Supabase Auth, bukan disimpan di tabel aplikasi.
- RLS membatasi pembacaan pesan ke anggota percakapan. Jangan menonaktifkan RLS.
- Username unik dan peka huruf besar/kecil pada constraint database saat ini; gunakan username yang berbeda persis.
- Jangan mengklaim website ini sudah aktif sebelum konfigurasi Supabase, deploy Vercel, dan uji dua akun selesai.
