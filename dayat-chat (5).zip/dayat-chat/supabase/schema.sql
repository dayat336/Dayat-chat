-- DAYAT CHAT DATABASE SETUP
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[A-Za-z0-9_]{3,24}$'),
  display_name text,
  role text not null default 'member' check (role in ('member','admin','owner')),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'dm' check (kind = 'dm'),
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id);

-- Create a profile whenever a new auth account is created.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  wanted_username text;
begin
  wanted_username := coalesce(new.raw_user_meta_data ->> 'username', 'user_' || substr(new.id::text,1,8));
  insert into public.profiles(id,username,display_name)
  values(new.id, wanted_username, wanted_username);
  return new;
exception when unique_violation then
  raise exception 'Nama pengguna sudah dipakai. Silakan daftar lagi dengan nama pengguna lain.';
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- SECURITY DEFINER helper avoids recursive RLS when checking conversation membership.
create or replace function public.is_conversation_member(p_conversation_id uuid, p_user_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = p_conversation_id and cm.user_id = p_user_id
  );
$$;
revoke all on function public.is_conversation_member(uuid,uuid) from public;
grant execute on function public.is_conversation_member(uuid,uuid) to authenticated;

-- Explicit table privileges; RLS policies below limit which rows are visible.
grant select on public.profiles to authenticated;
grant select on public.conversations to authenticated;
grant select on public.conversation_members to authenticated;
grant select on public.messages to authenticated;
grant insert on public.messages to authenticated;

-- Authenticated users can find other users to start chats. Role cannot be changed by normal profile updates.
drop policy if exists "profiles readable by authenticated" on public.profiles;
create policy "profiles readable by authenticated" on public.profiles for select to authenticated using (true);
drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles for update to authenticated
using (id = (select auth.uid())) with check (id = (select auth.uid()));
revoke update on public.profiles from authenticated;
grant update(username,display_name) on public.profiles to authenticated;

drop policy if exists "members read conversations" on public.conversations;
create policy "members read conversations" on public.conversations for select to authenticated
using (public.is_conversation_member(id, (select auth.uid())));

drop policy if exists "members read membership list" on public.conversation_members;
create policy "members read membership list" on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id, (select auth.uid())));

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated
using (public.is_conversation_member(conversation_id, (select auth.uid())));
drop policy if exists "members send as self" on public.messages;
create policy "members send as self" on public.messages for insert to authenticated
with check (sender_id=(select auth.uid()) and public.is_conversation_member(conversation_id, (select auth.uid())));

-- RPC creates a direct conversation without allowing clients to forge membership.
create or replace function public.get_or_create_dm(p_other_user uuid)
returns uuid language plpgsql security definer set search_path = ''
as $$
declare
  me uuid := auth.uid();
  found_id uuid;
  new_id uuid;
begin
  if me is null then raise exception 'Silakan masuk terlebih dahulu.'; end if;
  if p_other_user is null or p_other_user = me then raise exception 'Pilih pengguna lain.'; end if;
  if not exists(select 1 from public.profiles p where p.id=p_other_user) then raise exception 'Pengguna tidak ditemukan.'; end if;

  select c.id into found_id
  from public.conversations c
  where (select count(*) from public.conversation_members cm where cm.conversation_id=c.id)=2
    and exists(select 1 from public.conversation_members cm where cm.conversation_id=c.id and cm.user_id=me)
    and exists(select 1 from public.conversation_members cm where cm.conversation_id=c.id and cm.user_id=p_other_user)
  limit 1;
  if found_id is not null then return found_id; end if;

  insert into public.conversations(kind) values('dm') returning id into new_id;
  insert into public.conversation_members(conversation_id,user_id) values(new_id,me),(new_id,p_other_user);
  return new_id;
end;
$$;
revoke all on function public.get_or_create_dm(uuid) from public;
grant execute on function public.get_or_create_dm(uuid) to authenticated;

-- Only the existing Owner can promote/demote accounts to Admin/Member. No client can create another Owner.
create or replace function public.set_user_role(p_user_id uuid,p_role text)
returns void language plpgsql security definer set search_path = ''
as $$
begin
  if auth.uid() is null or not exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='owner') then
    raise exception 'Hanya Owner yang boleh mengubah peran.';
  end if;
  if p_role not in ('member','admin') then raise exception 'Peran hanya boleh Member atau Admin.'; end if;
  if p_user_id = auth.uid() then raise exception 'Owner tidak dapat mengubah perannya sendiri.'; end if;
  update public.profiles set role=p_role where id=p_user_id and role <> 'owner';
  if not found then raise exception 'Akun tidak ditemukan atau merupakan Owner.'; end if;
end;
$$;
revoke all on function public.set_user_role(uuid,text) from public;
grant execute on function public.set_user_role(uuid,text) to authenticated;

-- Enable realtime for new messages (safe to run repeatedly).
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;

-- IMPORTANT: after Dayat registers, use the owner-claim instructions in README.md.
