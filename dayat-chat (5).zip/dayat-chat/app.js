/* Dayat Chat — client-side app. Supabase anon/publishable key only; never put service_role here. */
const SUPABASE_URL = "PASTE_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const $ = (id) => document.getElementById(id);
let db = null, currentUser = null, myProfile = null, selectedUser = null, selectedConversation = null;
let messageChannel = null, profilesCache = [], conversationsCache = [], toastTimer = null;
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials = (name) => (String(name || "?").trim().slice(0,1) || "?").toUpperCase();
function notify(message) {
  $("toast").textContent = message; $("toast").classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $("toast").classList.remove("show"), 3000);
}
function setAuthMessage(message, success=false) {
  $("auth-message").textContent = message; $("auth-message").classList.toggle("success", success);
}
function showAuth() { $("auth-screen").classList.remove("hidden"); $("app-screen").classList.add("hidden"); }
function showApp() { $("auth-screen").classList.add("hidden"); $("app-screen").classList.remove("hidden"); }
function displayName(p) { return p?.display_name?.trim() || p?.username || "Pengguna"; }
function timeText(value) { return new Date(value).toLocaleTimeString("id-ID", {hour:"2-digit",minute:"2-digit"}); }
function dateText(value) {
  const d = new Date(value), today = new Date();
  if (d.toDateString() === today.toDateString()) return "Hari ini";
  return d.toLocaleDateString("id-ID", {day:"numeric",month:"short",year:d.getFullYear()===today.getFullYear()?undefined:"numeric"});
}
function setAuthMode(mode) {
  const signup = mode === "signup";
  $("tab-login").classList.toggle("active", !signup); $("tab-signup").classList.toggle("active", signup);
  $("username").classList.toggle("hidden", !signup); $("username-label").classList.toggle("hidden", !signup);
  $("username").required = signup; $("auth-submit").textContent = signup ? "Buat akun" : "Masuk";
  $("password").autocomplete = signup ? "new-password" : "current-password"; setAuthMessage("");
}
$("tab-login").addEventListener("click", () => setAuthMode("login"));
$("tab-signup").addEventListener("click", () => setAuthMode("signup"));

async function handleAuth(event) {
  event.preventDefault();
  if (!configured) { setAuthMessage("Konfigurasikan SUPABASE_URL dan SUPABASE_ANON_KEY di app.js terlebih dahulu."); return; }
  const signup = !$("username").classList.contains("hidden");
  const email = $("email").value.trim(), password = $("password").value, username = $("username").value.trim();
  $("auth-submit").disabled = true; $("auth-submit").textContent = "Tunggu...";
  try {
    if (signup) {
      if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) throw new Error("Nama pengguna 3–24 karakter; gunakan huruf, angka, atau garis bawah.");
      const {data,error} = await db.auth.signUp({email,password,options:{data:{username}}});
      if (error) throw error;
      if (!data.session) setAuthMessage("Akun dibuat. Periksa email untuk konfirmasi, lalu masuk.", true);
      else { setAuthMessage("Akun berhasil dibuat.", true); await bootUser(data.user); }
    } else {
      const {data,error} = await db.auth.signInWithPassword({email,password});
      if (error) throw error;
      await bootUser(data.user);
    }
  } catch (e) { setAuthMessage(e.message || "Terjadi kesalahan."); }
  finally { $("auth-submit").disabled = false; $("auth-submit").textContent = signup ? "Buat akun" : "Masuk"; }
}
$("auth-form").addEventListener("submit", handleAuth);

async function bootUser(user) {
  currentUser = user;
  const {data,error} = await db.from("profiles").select("id,username,display_name,role,created_at").eq("id",user.id).single();
  if (error) throw error;
  myProfile = data; showApp();
  $("my-name").textContent = displayName(myProfile); $("my-avatar").textContent = initials(displayName(myProfile));
  $("my-role").textContent = String(myProfile.role || "member").toUpperCase();
  $("admin-panel").classList.toggle("hidden", myProfile.role !== "owner");
  await loadPeople(); await loadConversations();
}
async function loadPeople() {
  const {data,error} = await db.from("profiles").select("id,username,display_name,role,created_at").neq("id",currentUser.id).order("username");
  if (error) throw error;
  profilesCache = data || []; renderPeople(); if (myProfile.role === "owner") renderAdminUsers();
}
function renderPeople() {
  const q = $("user-search").value.trim().toLowerCase();
  const rows = profilesCache.filter(p => `${p.username} ${p.display_name||""}`.toLowerCase().includes(q));
  $("users-list").innerHTML = rows.length ? rows.map(p => {
    const c = conversationsCache.find(x => x.other?.id === p.id);
    const active = selectedUser?.id === p.id;
    return `<button type="button" class="user-row ${active?"selected":""}" data-user-id="${escapeHtml(p.id)}">
      <div class="avatar">${escapeHtml(initials(displayName(p)))}</div>
      <div class="user-info"><div class="user-name-line"><strong>${escapeHtml(displayName(p))}</strong><span class="user-role">${p.role==="owner"?"OWNER":p.role==="admin"?"ADMIN":""}</span></div>
      <div class="user-preview">${escapeHtml(c?.lastMessage || "@"+p.username)}</div></div></button>`;
  }).join("") : `<div class="empty-list">${q ? "Pengguna tidak ditemukan." : "Belum ada teman terdaftar. Minta temanmu membuat akun."}</div>`;
  $("users-list").querySelectorAll("[data-user-id]").forEach(btn => btn.addEventListener("click", () => openChat(btn.dataset.userId)));
}
$("user-search").addEventListener("input", renderPeople);

async function loadConversations() {
  const {data,error} = await db.from("conversation_members").select("conversation_id,user_id,profiles(id,username,display_name,role)").eq("user_id",currentUser.id);
  if (error) throw error;
  const ids = [...new Set((data||[]).map(x=>x.conversation_id))];
  conversationsCache = [];
  for (const id of ids) {
    const {data:members} = await db.from("conversation_members").select("user_id,profiles(id,username,display_name,role)").eq("conversation_id",id);
    const other = (members||[]).map(m=>m.profiles).find(p=>p && p.id!==currentUser.id);
    if (!other) continue;
    const {data:latest} = await db.from("messages").select("body,created_at").eq("conversation_id",id).order("created_at",{ascending:false}).limit(1).maybeSingle();
    conversationsCache.push({id,other,lastMessage:latest?.body || "",lastAt:latest?.created_at || ""});
  }
  conversationsCache.sort((a,b)=>new Date(b.lastAt||0)-new Date(a.lastAt||0)); renderPeople();
}
async function openChat(userId) {
  selectedUser = profilesCache.find(p => p.id === userId);
  if (!selectedUser) return;
  try {
    const {data,error} = await db.rpc("get_or_create_dm",{p_other_user:userId});
    if (error) throw error;
    selectedConversation = data;
    $("welcome-panel").classList.add("hidden"); $("conversation-panel").classList.remove("hidden");
    $("chat-name").textContent = displayName(selectedUser); $("chat-avatar").textContent = initials(displayName(selectedUser));
    $("chat-subtitle").textContent = selectedUser.role==="owner" ? "Owner • Chat pribadi" : "Chat pribadi";
    $("app-screen").classList.add("chat-open"); renderPeople();
    await loadMessages(); subscribeMessages(); $("message-input").focus();
  } catch(e) { notify(e.message || "Tidak bisa membuka chat."); }
}
$("back-btn").addEventListener("click", () => $("app-screen").classList.remove("chat-open"));

async function loadMessages() {
  const {data,error} = await db.from("messages").select("id,conversation_id,sender_id,body,created_at").eq("conversation_id",selectedConversation).order("created_at",{ascending:true}).limit(500);
  if (error) throw error;
  renderMessages(data || []);
}
function renderMessages(messages) {
  const box = $("messages"), atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
  let previousDate = "";
  box.innerHTML = messages.map(m => {
    const day = dateText(m.created_at);
    const divider = day !== previousDate ? `<div class="day-divider">${escapeHtml(day)}</div>` : "";
    previousDate = day;
    const mine = m.sender_id === currentUser.id;
    return `${divider}<div class="bubble ${mine?"mine":"theirs"}">${escapeHtml(m.body)}<div class="bubble-meta"><span>${timeText(m.created_at)}</span>${mine?'<span class="ticks">✓</span>':""}</div></div>`;
  }).join("");
  if (atBottom || messages.length < 2) box.scrollTop = box.scrollHeight;
}
function subscribeMessages() {
  if (messageChannel) db.removeChannel(messageChannel);
  const convo = selectedConversation;
  messageChannel = db.channel("messages-"+convo).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:"conversation_id=eq."+convo},payload => {
    if (selectedConversation === convo) loadMessages().catch(e=>notify(e.message));
    loadConversations().catch(()=>{});
  }).subscribe();
}
$("message-form").addEventListener("submit", async event => {
  event.preventDefault();
  const body = $("message-input").value.trim();
  if (!body || !selectedConversation) return;
  $("send-btn").disabled = true;
  try {
    const {error} = await db.from("messages").insert({conversation_id:selectedConversation,sender_id:currentUser.id,body});
    if (error) throw error;
    $("message-input").value = "";
    await loadMessages(); await loadConversations();
  } catch(e) { notify(e.message || "Pesan gagal dikirim."); }
  finally { $("send-btn").disabled = false; $("message-input").focus(); }
});

async function renderAdminUsers() {
  const host = $("admin-users");
  host.innerHTML = profilesCache.map(p => `<div class="admin-row"><span>${escapeHtml(p.username)}${p.id===currentUser.id?" (kamu)":""}</span><select data-role-id="${escapeHtml(p.id)}" ${p.role==="owner"?"disabled":""}><option value="member" ${p.role==="member"?"selected":""}>Member</option><option value="admin" ${p.role==="admin"?"selected":""}>Admin</option></select></div>`).join("");
  host.querySelectorAll("select[data-role-id]").forEach(select => select.addEventListener("change", async () => {
    try {
      const {error} = await db.rpc("set_user_role",{p_user_id:select.dataset.roleId,p_role:select.value});
      if (error) throw error;
      notify("Peran akun diperbarui."); await loadPeople();
    } catch(e) { notify(e.message || "Gagal mengubah peran."); await loadPeople(); }
  }));
}
$("logout-btn").addEventListener("click", async () => {
  if (messageChannel) await db.removeChannel(messageChannel);
  await db.auth.signOut(); currentUser=null; myProfile=null; selectedUser=null; selectedConversation=null; conversationsCache=[]; profilesCache=[];
  $("app-screen").classList.remove("chat-open"); showAuth(); $("password").value=""; setAuthMessage("Kamu sudah keluar.",true);
});

async function init() {
  if (!configured) { showAuth(); setAuthMessage("Sebelum dipakai, isi URL dan anon/publishable key Supabase di app.js."); return; }
  db = window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY);
  const {data:{session}} = await db.auth.getSession();
  if (session?.user) { try { await bootUser(session.user); } catch(e) { showAuth(); setAuthMessage(e.message || "Gagal memuat akun."); } }
  else showAuth();
  db.auth.onAuthStateChange(async (event,session) => {
    if (event==="SIGNED_OUT") showAuth();
    else if (event==="SIGNED_IN" && session?.user && !currentUser) {
      try { await bootUser(session.user); } catch(e) { showAuth(); setAuthMessage(e.message || "Gagal memuat akun."); }
    }
  });
}
init();
